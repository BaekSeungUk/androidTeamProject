package com.example.groupproject

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.groupproject.databinding.ItemEmgmedBinding


class EmgMedAdapter : ListAdapter<Item, EmgMedAdapter.EmViewHolder>(EmgMedCallBack){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmViewHolder {
        val binding = ItemEmgmedBinding.inflate(LayoutInflater.from(parent.context), parent,false)
        return EmViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EmViewHolder, position: Int){
        holder.bind(getItem(position))
    }

    class EmViewHolder(private val binding: ItemEmgmedBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(item: Item){
            with(binding){
                    MAINTITLE.text = item.mAINTITLE
                    GUGUNNM.text = item.gUGUNNM

                        Glide.with(itemView)
                            .load(item.mAINIMGTHUMB)
                            .into(binding.THUM)

            }
        }

    }
    companion object {
        private val EmgMedCallBack = object : DiffUtil.ItemCallback<Item>(){
            override fun areItemsTheSame(oldItem: Item, newItem: Item): Boolean {
                return oldItem.hashCode() == newItem.hashCode()
            }

            override fun areContentsTheSame(oldItem: Item, newItem: Item): Boolean {
                return oldItem == newItem
            }

        }
    }

}